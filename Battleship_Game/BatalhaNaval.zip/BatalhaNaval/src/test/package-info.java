/**
 * Package test contains the junit tests to the game logic
 */
package test;