package gui;

/**
 * The Class StatisticsMenu is used to show statistics before game starts
 */
public class StatisticsMenu {
	
	/**
	 * Instantiates a new statistics menu.
	 */
	public StatisticsMenu(){
		
	}
}
