/**
 * Package gui contains the graphical user interface for the game
 */
package gui;