/**
 * Package cli contains the command line interface for the game
 */
package cli;