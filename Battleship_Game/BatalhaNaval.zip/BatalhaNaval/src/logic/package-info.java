/**
 * Package logic contains the game logic, to be used by cli, gui and server
 */
package logic;