/**
 * Package audio containing the game sounds
 */
package audio;